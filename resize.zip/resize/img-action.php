<?php

function resizeImage($CurWidth,$CurHeight,$MaxSize,$DestFolder,$SrcImage,$Quality,$ImageType)
{
	//Check Image size is not 0
	if($CurWidth <= 0 || $CurHeight <= 0) 
		{	return false;
		}
	
	//Construct a proportional size of new image
	$ImageScale      	= min($MaxSize/$CurWidth, $MaxSize/$CurHeight); 
	$NewWidth  		= ceil($ImageScale*$CurWidth);
	$NewHeight 		= ceil($ImageScale*$CurHeight);
	
	if($CurWidth < $NewWidth || $CurHeight < $NewHeight)
		{	$NewWidth = $CurWidth;
			$NewHeight = $CurHeight;
		}
	$NewCanves 	= imagecreatetruecolor($NewWidth, $NewHeight);
	// Resize Image
	if(imagecopyresampled($NewCanves, $SrcImage,0, 0, 0, 0, $NewWidth, $NewHeight, $CurWidth, $CurHeight))
		{	switch(strtolower($ImageType))
				{	case 'image/png':
						imagepng($NewCanves,$DestFolder);
						break;
					case 'image/gif':
						imagegif($NewCanves,$DestFolder);
						break;			
					case 'image/jpeg':
					case 'image/pjpeg':
						imagejpeg($NewCanves,$DestFolder,$Quality);
						break;
					default:
						return false;
				}
			if(is_resource($NewCanves)) 
				{ imagedestroy($NewCanves); 
				} 
			return true;
		}

}


if(isset($_FILES['file']['name'])){
		
	if( $_FILES['file']['size']<5000000 ){


			//Some Settings
			$BigImageMaxSize 				= 300; //Image Maximum height or width
			$ResizePrefix					= "resized_"; //Normal resize Prefix
			$OriginalDestinationDirectory	= 'original/';
			$ResizedDestinationDirectory	= 'resized/'; //Upload Directory ends with / (slash)
			$Quality 						= 100;
			$ResizedImageLocation[] 		= "";
			$OriginalImageLocation[]		= "";

			// some information about image we need later.
			$ImageName=$_FILES['file']["name"];
			$ImageSize=$_FILES['file']['size'];
			$TempSrc=$_FILES['file']['tmp_name'];
			$ImageType=$_FILES['file']['type'];

			$processImage = true;
			
			
			//Validate file + create image from uploaded file.
					switch(strtolower($ImageType))
						{		case 'image/png':
									$CreatedImage = imagecreatefrompng($TempSrc);
									break;
								case 'image/gif':
									$CreatedImage = imagecreatefromgif($TempSrc);
									break;
								case 'image/jpeg':
								case 'image/pjpeg':
									$CreatedImage = imagecreatefromjpeg($TempSrc);
									break;
								default:
									$processImage = false; //image format is not supported!
						}
							
					//get Image Size
					list($CurWidth,$CurHeight) = getimagesize($TempSrc);

					//Set the Destination Image path
					$DestRandImageName 			= $ResizedDestinationDirectory.$ResizePrefix.$ImageName; //Name for Big Image
					$OriginalImageName			= $OriginalDestinationDirectory.$ImageName;	// Original Image Name
							
					$moveImage = move_uploaded_file($TempSrc, $OriginalImageName);

					//Resize image to our Specified Size by calling resizeImage function.
					if($processImage && resizeImage($CurWidth,$CurHeight,$BigImageMaxSize,$DestRandImageName,$CreatedImage,$Quality,$ImageType))
						{	
					
							//Get New Image Size
							list($ResizedWidth,$ResizedHeight)=getimagesize($DestRandImageName);
							$ResizedImageLocation	= $DestRandImageName;
							$OriginalImageLocation	= $OriginalImageName;
							
							echo 'You can view your images here<br>
								
							<p><a href="'.$OriginalImageLocation.'" target="_blank">Original Image</a></p>
							<p><a href="'.$ResizedImageLocation.'" target="_blank">Resized Image (resized to maximum height/width 300px)</a> <br> Images having both height/width less than 300px not resized</p>
							
							';
							

						}
					else
						{	echo '<p style="color:red;">Error occurred while trying to process <strong>'.$ImageName.'</strong>! Please check if file is supported</div>'; //output error
						}

	}
	
	else{
		echo '<p style="color:red;">Please upload image of maximum size 5MB</p>';
	}

}

?>