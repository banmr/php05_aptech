<h2>Image Resizer</h2>

<form enctype="multipart/form-data" action="img-action.php" method="post" >
	
	<label for="file">Image</label>
	<input type="file" name="file" id="file" required />
	
	
	<br><br>
	<input type="submit" value="Submit" />

</form>